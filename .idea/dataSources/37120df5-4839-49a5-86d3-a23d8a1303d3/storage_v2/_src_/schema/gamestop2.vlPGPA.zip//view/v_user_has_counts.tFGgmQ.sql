create definer = gamestop2@localhost view v_user_has_counts as
select `H`.`UID` AS `UID`, `H`.`GID` AS `GID`, `G`.`Title` AS `Title`, count(0) AS `cnt`
from (`gamestop2`.`Has` `H` join `gamestop2`.`Games` `G` on (`G`.`GID` = `H`.`GID`))
group by `H`.`UID`, `H`.`GID`;

