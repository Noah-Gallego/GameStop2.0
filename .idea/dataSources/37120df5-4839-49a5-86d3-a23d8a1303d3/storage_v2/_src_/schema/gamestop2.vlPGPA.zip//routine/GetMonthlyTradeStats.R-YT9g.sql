create
    definer = gamestop2@localhost procedure GetMonthlyTradeStats(IN p_StartDate date, IN p_EndDate date)
BEGIN
    SELECT COUNT(*) AS TotalTrades,
           AVG(DATEDIFF(NOW(), Timestamp)) AS AvgDaysSinceTrade
    FROM Trades
    WHERE Timestamp BETWEEN p_StartDate AND p_EndDate;
END;

