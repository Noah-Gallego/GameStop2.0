create
    definer = gamestop2@localhost procedure DeleteUser(IN p_UID int)
BEGIN
    DELETE FROM Users WHERE UID = p_UID;
END;

