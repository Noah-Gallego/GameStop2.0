create definer = gamestop2@localhost view v_user_trade_direction as
select `gamestop2`.`Trades`.`UID1` AS `uid`, 'Started' AS `label`, count(0) AS `cnt`
from `gamestop2`.`Trades`
group by `gamestop2`.`Trades`.`UID1`
union all
select `gamestop2`.`Trades`.`UID2` AS `uid`, 'Received' AS `label`, count(0) AS `cnt`
from `gamestop2`.`Trades`
group by `gamestop2`.`Trades`.`UID2`;

