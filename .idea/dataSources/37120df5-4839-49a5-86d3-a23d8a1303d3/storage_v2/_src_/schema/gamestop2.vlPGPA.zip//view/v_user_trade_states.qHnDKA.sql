create definer = gamestop2@localhost view v_user_trade_states as
select `x`.`uid` AS `uid`, `x`.`State` AS `label`, count(0) AS `cnt`
from (select `gamestop2`.`Trades`.`UID1` AS `uid`, `gamestop2`.`Trades`.`State` AS `State`
      from `gamestop2`.`Trades`
      union all
      select `gamestop2`.`Trades`.`UID2` AS `uid`, `gamestop2`.`Trades`.`State` AS `State`
      from `gamestop2`.`Trades`) `x`
group by `x`.`uid`, `x`.`State`;

