create
    definer = gamestop2@localhost procedure sp_monthly_trade_stats(IN p_start date, IN p_end date)
BEGIN
    SELECT
        COUNT(*)                                      AS total_trades,
        SUM(GID1 IS NOT NULL AND GID2 IS NOT NULL)    AS n_swaps,
        SUM((GID1 IS NOT NULL) XOR (GID2 IS NOT NULL))AS n_gifts,
        AVG(TIMESTAMPDIFF(HOUR, Timestamp, NOW()))    AS avg_hours_open
    FROM Trades
    WHERE DATE(Timestamp) BETWEEN p_start AND p_end
      AND State = 'Completed';
END;

