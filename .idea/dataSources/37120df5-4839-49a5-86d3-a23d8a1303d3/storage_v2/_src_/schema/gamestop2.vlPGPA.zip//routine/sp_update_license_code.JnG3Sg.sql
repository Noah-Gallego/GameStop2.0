create
    definer = gamestop2@localhost procedure sp_update_license_code(IN p_old varchar(50), IN p_new varchar(50))
BEGIN
    UPDATE Has
       SET License = p_new
     WHERE License = p_old;
END;

