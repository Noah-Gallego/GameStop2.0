create
    definer = gamestop2@localhost procedure DeleteWant(IN i_uid int, IN i_gid int)
BEGIN
    DELETE FROM Wants WHERE UID = i_uid AND GID = i_gid;
END;

