create
    definer = gamestop2@localhost procedure finalize_trade(IN p_tid int)
BEGIN
    
    UPDATE Trades
       SET State     = 'Completed'
     WHERE TID        = p_tid
       AND State      = 'Pending'
       AND Status1    = 'Accepted'
       AND Status2    = 'Accepted';
        
        
END;

