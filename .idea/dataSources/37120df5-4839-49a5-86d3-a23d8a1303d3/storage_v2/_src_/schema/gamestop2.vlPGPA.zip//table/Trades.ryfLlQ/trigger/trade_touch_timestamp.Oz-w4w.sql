create definer = gamestop2@localhost trigger trade_touch_timestamp
    before update
    on Trades
    for each row
BEGIN
    IF  NEW.Status1 <> OLD.Status1
     OR NEW.Status2 <> OLD.Status2
     OR NEW.State   <> OLD.State   THEN
        SET NEW.Timestamp = NOW();
    END IF;
END;

