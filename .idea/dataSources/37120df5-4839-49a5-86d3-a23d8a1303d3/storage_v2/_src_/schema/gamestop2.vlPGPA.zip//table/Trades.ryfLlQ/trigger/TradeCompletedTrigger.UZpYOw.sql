create definer = gamestop2@localhost trigger TradeCompletedTrigger
    after update
    on Trades
    for each row
BEGIN
    DECLARE license1 VARCHAR(50);
    DECLARE license2 VARCHAR(50);

    
    IF NEW.State = 'Completed' AND OLD.State != 'Completed' THEN

        
        IF NEW.GID1 IS NOT NULL THEN
            
            SELECT License INTO license1
            FROM Has
            WHERE UID = NEW.UID1
              AND GID = NEW.GID1
            LIMIT 1;

            
            DELETE FROM Has
            WHERE UID = NEW.UID1 AND License = license1;

            
            INSERT INTO Has (License, UID, GID)
            VALUES (license1, NEW.UID2, NEW.GID1);
        END IF;

        
        IF NEW.GID2 IS NOT NULL THEN
            
            SELECT License INTO license2
            FROM Has
            WHERE UID = NEW.UID2
              AND GID = NEW.GID2
            LIMIT 1;

            
            DELETE FROM Has
            WHERE UID = NEW.UID2 AND License = license2;

            
            INSERT INTO Has (License, UID, GID)
            VALUES (license2, NEW.UID1, NEW.GID2);
        END IF;

        INSERT INTO TradeHistory (TradeID, SenderID, GID1, License1, ReceiverID, GID2, License2, State)
        VALUES (New.TID, NEW.UID1, NEW.GID1, license1, NEW.UID2, NEW.GID2, license2, 'Completed');
    END IF;
END;

