create definer = gamestop2@localhost trigger wants_priority_update
    before update
    on Wants
    for each row
BEGIN
    IF NEW.Priority <> OLD.Priority THEN
        SET NEW.Date = NOW();
    END IF;
END;

