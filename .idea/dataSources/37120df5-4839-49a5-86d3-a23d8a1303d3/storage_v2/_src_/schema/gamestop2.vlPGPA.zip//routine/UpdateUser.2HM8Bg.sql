create
    definer = gamestop2@localhost procedure UpdateUser(IN p_UID int, IN p_Email varchar(100),
                                                       IN p_Password varchar(255), IN p_FirstName varchar(50),
                                                       IN p_LastName varchar(50))
BEGIN
    UPDATE Users
    SET Email = p_Email,
        Password = p_Password,
        FirstName = p_FirstName,
        LastName = p_LastName
    WHERE UID = p_UID;
END;

