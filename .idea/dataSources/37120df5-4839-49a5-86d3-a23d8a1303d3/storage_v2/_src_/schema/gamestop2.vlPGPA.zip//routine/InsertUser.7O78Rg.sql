create
    definer = gamestop2@localhost procedure InsertUser(IN p_Email varchar(100), IN p_Password varchar(255),
                                                       IN p_FirstName varchar(50), IN p_LastName varchar(50))
BEGIN
    INSERT INTO Users (Email, Password, FirstName, LastName)
    VALUES (p_Email, p_Password, p_FirstName, p_LastName);
END;

