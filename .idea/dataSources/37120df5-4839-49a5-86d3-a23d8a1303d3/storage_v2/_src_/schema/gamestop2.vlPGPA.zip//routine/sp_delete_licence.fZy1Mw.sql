create
    definer = gamestop2@localhost procedure sp_delete_licence(IN p_license varchar(50))
BEGIN
    DELETE FROM Has
    WHERE License = p_license;
END;

