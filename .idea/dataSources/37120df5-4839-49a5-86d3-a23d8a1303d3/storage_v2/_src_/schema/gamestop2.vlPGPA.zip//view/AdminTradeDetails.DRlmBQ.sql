create definer = crodriguez@localhost view AdminTradeDetails as
select `t`.`TID`                             AS `TID`,
       substring_index(`u1`.`Email`, '@', 1) AS `User1`,
       substring_index(`u2`.`Email`, '@', 1) AS `User2`,
       `g1`.`Title`                          AS `User1Game`,
       `g2`.`Title`                          AS `User2Game`,
       `t`.`State`                           AS `State`,
       `h1`.`License`                        AS `User1License`,
       `h2`.`License`                        AS `User2License`,
       `t`.`Timestamp`                       AS `Timestamp`
from ((((((`gamestop2`.`Trades` `t` join `gamestop2`.`Users` `u1`
           on (`t`.`UID1` = `u1`.`UID`)) join `gamestop2`.`Users` `u2`
          on (`t`.`UID2` = `u2`.`UID`)) join `gamestop2`.`Games` `g1`
         on (`t`.`GID1` = `g1`.`GID`)) join `gamestop2`.`Games` `g2`
        on (`t`.`GID2` = `g2`.`GID`)) left join `gamestop2`.`Has` `h1`
       on (`h1`.`UID` = `t`.`UID1` and `h1`.`GID` = `t`.`GID1`)) left join `gamestop2`.`Has` `h2`
      on (`h2`.`UID` = `t`.`UID2` and `h2`.`GID` = `t`.`GID2`));

