create definer = gamestop2@localhost view AdminTradeDetails as
select `th`.`HistoryID`                      AS `HistoryID`,
       `th`.`TradeID`                        AS `TradeID`,
       substring_index(`u1`.`Email`, '@', 1) AS `Sender`,
       substring_index(`u2`.`Email`, '@', 1) AS `Receiver`,
       `g1`.`Title`                          AS `SenderGame`,
       `g2`.`Title`                          AS `ReceiverGame`,
       `th`.`License1`                       AS `License1`,
       `th`.`License2`                       AS `License2`,
       `th`.`EventTime`                      AS `CompletedAt`
from ((((`gamestop2`.`TradeHistory` `th` join `gamestop2`.`Users` `u1`
         on (`u1`.`UID` = `th`.`SenderID`)) join `gamestop2`.`Users` `u2`
        on (`u2`.`UID` = `th`.`ReceiverID`)) left join `gamestop2`.`Games` `g1`
       on (`g1`.`GID` = `th`.`GID1`)) left join `gamestop2`.`Games` `g2` on (`g2`.`GID` = `th`.`GID2`));

