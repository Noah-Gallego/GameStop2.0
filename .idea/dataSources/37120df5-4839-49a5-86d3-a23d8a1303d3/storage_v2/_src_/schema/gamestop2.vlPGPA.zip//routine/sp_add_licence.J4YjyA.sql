create
    definer = gamestop2@localhost procedure sp_add_licence(IN p_license varchar(50), IN p_uid int, IN p_gid int)
BEGIN
    INSERT INTO Has (License, UID, GID)
    VALUES (p_license, p_uid, p_gid);
END;

