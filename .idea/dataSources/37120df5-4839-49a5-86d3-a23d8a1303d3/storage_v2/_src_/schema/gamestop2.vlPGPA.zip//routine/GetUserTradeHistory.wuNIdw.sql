create
    definer = gamestop2@localhost procedure GetUserTradeHistory(IN p_UID int)
BEGIN
    SELECT  g1.Title AS SentGame,
            CASE
              WHEN t.UID1 = p_UID
                     THEN SUBSTRING_INDEX(u2.Email,'@',1)
              ELSE      SUBSTRING_INDEX(u1.Email,'@',1)
            END  AS TradePartner,
            g2.Title AS ReceivedGame,
            t.State  AS Status
    FROM Trades t
    JOIN Users  u1 ON t.UID1 = u1.UID
    JOIN Users  u2 ON t.UID2 = u2.UID
    JOIN Games  g1 ON t.GID1 = g1.GID
    JOIN Games  g2 ON t.GID2 = g2.GID
    WHERE t.UID1 = p_UID OR t.UID2 = p_UID;
END;

